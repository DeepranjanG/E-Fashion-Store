-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2018 at 04:34 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tutorial`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=44 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `brand`) VALUES
(1, 'Levis'),
(2, 'Nike'),
(7, 'Polo'),
(8, 'Sketchers'),
(9, 'Calvin Klein'),
(10, 'Charter Club'),
(11, 'Helly Hanson'),
(12, 'Tommy Hilfiger'),
(13, 'Vince Camuto'),
(14, 'Chiffon'),
(15, 'Hp'),
(16, 'Pieces'),
(17, 'Rodid'),
(18, 'Highlander'),
(19, 'Aarika'),
(20, 'Beekay'),
(21, 'AJ Dezines'),
(22, 'FTC '),
(23, 'Abhushan'),
(24, 'Webelkart'),
(25, 'Apple'),
(26, 'Puma'),
(27, 'Adbucks'),
(28, 'Fingerchips&#039;s'),
(29, 'Kidopedia'),
(30, 'Flying Machine'),
(31, 'Metronaut'),
(32, 'Beevee'),
(33, 'Smoky'),
(34, 'Kraasa'),
(35, 'Emporio Armani'),
(36, 'GUCCI'),
(37, 'Saints'),
(38, 'CRAFTBAZAR'),
(39, 'Benji'),
(40, 'Carlton London'),
(41, 'Accessorize'),
(42, 'Crocs Crocs'),
(43, 'Satva');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items` text COLLATE utf8_unicode_ci NOT NULL,
  `expire_date` datetime NOT NULL,
  `paid` tinyint(4) NOT NULL DEFAULT '0',
  `shipped` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=55 ;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `items`, `expire_date`, `paid`, `shipped`) VALUES
(26, '[{"id":"29","size":"N/A","quantity":"2"},{"id":"24","size":"XL","quantity":"3"},{"id":"26","size":"M","quantity":"2"}]', '2018-03-05 05:00:03', 1, 0),
(29, '[{"id":"29","size":"N/A","quantity":"3"},{"id":"33","size":"N/A","quantity":"1"},{"id":"27","size":"N/A","quantity":"2"},{"id":"26","size":"M","quantity":"1"}]', '2018-04-30 05:44:55', 1, 0),
(38, '[{"id":"28","size":"12 yrs","quantity":"1"}]', '2018-05-05 19:59:18', 1, 0),
(47, '[{"id":"25","size":"L","quantity":"3"}]', '2018-05-07 05:35:26', 1, 0),
(50, '[{"id":"32","size":"N/A","quantity":"1"}]', '2018-05-07 05:47:01', 1, 0),
(51, '[{"id":"30","size":"N/A","quantity":"1"}]', '2018-05-07 06:06:48', 1, 0),
(52, '[{"id":"25","size":"M","quantity":"3"}]', '2018-05-25 05:16:03', 0, 0),
(53, '[{"id":"34","size":"15 inch","quantity":"1"}]', '2018-05-29 12:03:56', 0, 0),
(54, '[{"id":"36","size":"4-5 yrs","quantity":"1"}]', '2018-05-30 16:32:22', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=34 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `parent`) VALUES
(1, 'Men', 0),
(2, 'Women', 0),
(3, 'Boys', 0),
(4, 'Girls', 0),
(5, 'Shirts', 1),
(6, 'Pants', 1),
(7, 'Shoes', 1),
(8, 'Accessories', 1),
(9, 'Shirts', 2),
(10, 'Pants', 2),
(11, 'Shoes', 2),
(12, 'Dresses', 2),
(13, 'Shirts', 3),
(14, 'Pants', 3),
(15, 'Dresses', 4),
(16, 'Shoes', 4),
(17, 'Accessories', 2),
(25, 'Gifts', 0),
(26, 'Home Decor', 25),
(27, 'Shoes', 3),
(28, 'Pants', 4),
(29, 'Electronics', 0),
(30, 'Laptop', 29),
(31, 'T shirt', 1),
(32, 'Dresses', 3),
(33, 'Painting', 25);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `list_price` decimal(10,2) NOT NULL,
  `brand` int(11) NOT NULL,
  `categories` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `featured` tinyint(4) NOT NULL DEFAULT '0',
  `sizes` text COLLATE utf8_unicode_ci NOT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=57 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `price`, `list_price`, `brand`, `categories`, `image`, `description`, `featured`, `sizes`, `deleted`) VALUES
(24, 'Rodid Men&#039;s Solid Casual Black Shirt', '39.99', '49.99', 17, '5', '/Tutorial/images/products/85cb9d4d4c7c912a0507cead964399cb.jpeg,/Tutorial/images/products/c6a3438abdd6010dd78a87592147390f.jpeg,/Tutorial/images/products/148f92f851dc93ef4bb2edb383c58a01.jpeg', 'Black Shirt With Charcoal Milange Knits Sleeve for Attractive styling.\r\n Looks Best when tucked in.', 1, 'L:6:2,XL:3:2,M:3:2', 0),
(25, 'Men&#039;s Printed Casual Brown Shirt', '50.99', '60.99', 18, '5', '/Tutorial/images/products/7035605a4a95016482fecda9208aebbb.jpeg,/Tutorial/images/products/f748d946454fccd2cf070ba897af363c.jpeg,/Tutorial/images/products/cbf42e9dd3129d31e5f339bf8279edf4.jpeg,/Tutorial/images/products/20f384021a0129a1a81c55847fa070aa.jpeg,/Tutorial/images/products/b9a605c74e5ecd49f77d8a88013c88bf.jpeg', 'This model has a Height of 6 feet 0 inches, Chest 40 inches, Waist 32 inches and is wearing a of Size Regular Machine Wash,\r\n Dry in shade, \r\nWash with like colors,\r\n Machine wash as per tag', 1, 'M:4:,L:2:,XL:5:', 0),
(26, 'PerfectFit Solid Men Round Neck Grey,', '25.99', '35.99', 2, '31', '/Tutorial/images/products/746f93cc9c55193e658b8102e783cde9.jpeg,/Tutorial/images/products/55fbf770295751a6443d8d560fcc2630.jpeg,/Tutorial/images/products/ac3d4ee9d6cac92e1c8df424ba80ac91.jpeg,/Tutorial/images/products/9bc82d7d43ec62f0be83c1096edf29c8.jpeg,/Tutorial/images/products/a295be80b3acc208bd08f901ff0e5ba4.jpeg,/Tutorial/images/products/0a552f352ddfaaf717519315e5b8f746.jpeg', 'Material is very soft and comfortable. \r\nFitting is fantastic.\r\nDesign is Faboulous. This product is one of best product.\r\nEveryone must try once.', 1, 'M:4:2,L:4:2', 0),
(27, 'Active Anarkali Gown  (Black)', '70.99', '80.99', 8, '12', '/Tutorial/images/products/48588ba754ec3c4f171d481fed297b0d.jpeg,/Tutorial/images/products/39a6f5c1d9734ae7e1766962133f555c.jpeg,/Tutorial/images/products/d75f30220c913b4ddacad1baef7eb6b8.jpeg,/Tutorial/images/products/aaf20e447066c6b14b38343bb92549eb.jpeg', 'Fabric : Heavy Banglori Silk, \r\nBottom : Santoon, \r\nDupatta : Net, \r\nWork : Heavy Embroidery, \r\nType : Semi-stitched, \r\nColour :- Black', 1, 'N/A:4:2', 0),
(28, 'Aarika Girls Festive &amp; Party Top and Skirt Set', '49.99', '59.99', 19, '15', '/Tutorial/images/products/919fd0ebdddff9742d65be096fedf79e.jpeg,/Tutorial/images/products/1d4977cf761bf3424235ae6a94e59222.jpeg,/Tutorial/images/products/9f0e062e0dc77417b982350ce9b059a3.jpeg', 'Let your girl be the centre of attention when you buy her this adorable dress from Aarika. \r\nFeaturing a beautiful design, this dress offers absolute comfort which will make your princess look glamorous. Perfect for every occasion, style it with delicate shoes and a trendy hair accessory to complete the look.\r\n Aarika is a contemporary clothing and lifestyle brand that embodies the modern style of young fashionistas. \r\nThe range includes Frocks, Dresses, Jumpsuits, Gowns, Lehenga-Choli, Pajami-Suit, and Palazzo Suit. Sales Package: 1 Top, 1 Skirt and 1 Sling Bag', 1, '12 yrs:4:2,15 yrs:5:2', 0),
(29, 'Girls Midi/Knee Length Party Dress', '39.99', '49.99', 20, '15', '/Tutorial/images/products/cd5d1977b383ea892cb04cca7764493b.jpeg,/Tutorial/images/products/9fc253ea3a78089de2c8ed677865ecb0.jpeg,/Tutorial/images/products/58f1910d4382e43020fce2965f193d66.jpeg,/Tutorial/images/products/2ea7d83dcccc098e201338793a90ba00.jpeg', 'Clasic &amp; Gorgeous looking frock for girls\r\nFabric: Crepe\r\nColor: Blue\r\nCharacter: No Character\r\nType: A- Line Dress\r\nMidi/Knee Length Dress', 1, 'N/A:5:2', 0),
(30, 'Boys Festive &amp; Party Kurta', '79.99', '89.99', 21, '32', '/Tutorial/images/products/1d638185bbad0de1aa5f4295b417f98d.jpeg,/Tutorial/images/products/f42b527eeecebdf7447c62e5ba14f067.jpeg,/Tutorial/images/products/58e13ed1c240cd5bf2448082b748c47e.jpeg', 'Make your boy look like prince by buying him this Maroon 3-piece Indo Western set from AJ Dezines. Made from cotton blend material, this boys ethnic wear set comprises churidar bottoms, kurta and waistcoat. The waistcoat has modi collar that makes your boy look all the more stylish and give him perfect traditional look. The fit is regular for boys clothing.\r\n This boys ethnic dress is ideal for the special parties, functions, festival, wedding and other occasion. Club it with a pair of mojadis for perfect traditional look. \r\nWe are leading Brand in kids wear with wide range of kids clothing which includes kids ethnic wear, casual wear, accessories and a lot more.', 1, 'N/A:2:', 0),
(31, 'Festive &amp; Party Kurta and Pyjama', '55.99', '65.99', 22, '32', '/Tutorial/images/products/f24879522a417e7fd884d4b1432ba4aa.jpeg,/Tutorial/images/products/2fda79d97aba8f495baa7c8a24b5ca53.jpeg,/Tutorial/images/products/ad703f19b734d3a983408ffb2cd65f73.jpeg,/Tutorial/images/products/e156883ebcb3f91718328b40c100cee8.jpeg', 'Fabric: Khadi\r\nColor: Multicolor\r\nIdeal For: Boys\r\nPattern: Self Design\r\nFull Sleeve Kurta and Pyjama Set', 1, 'N/A:5:2', 0),
(32, 'Ganesh Ji face Encircled With Suraj Ji', '55.99', '65.99', 23, '33', '/Tutorial/images/products/6e746466135e8c32f6f774fe1453a712.jpeg,/Tutorial/images/products/9b7b6e43e16ffdbc77fd013c2c00857e.jpeg,/Tutorial/images/products/0b8ebaa789a96b943ef444da0b7a94f7.jpeg', 'Abhushan is bringing prosperity and happiness to your living space by keeping this Idol Wall Hanging Plate.\r\nIt is also an ideal gift for several occasions such as Wedding Gifts, Corporate Gifts, Birthday Gifts, Diwali Gifts, Rakhi Gifts, New Year Gifts and Compliments, etc.\r\nThe product has been designed quite intelligently and features a Lord Ganesha Wall Hanging\r\n\r\n.As the god of success,Lord Ganesh names are chanted at the start of any important venture. Made from brass , it is durable and sturdy. A wonderful item for use in Puja', 1, 'N/A:0:', 0),
(33, 'WebelKart Pair OF Kissing Duck  ', '29.99', '39.99', 24, '26', '/Tutorial/images/products/00b7213d2534873c706f62056bf96e57.jpeg,/Tutorial/images/products/7094cd1acdc3e2f5cd6e8327e07b30bd.jpeg,/Tutorial/images/products/35b7b101df1df99d5519022649617cd0.jpeg', 'Home Decor - Spiritual &amp; Festive Decor, \r\nHome Decor - Table Decor &amp; Handicrafts\r\n', 1, 'N/A:4:2', 0),
(34, 'Apple Macbook Pro Core i7', '149.99', '199.99', 25, '30', '/Tutorial/images/products/9636e7af3f2d7a625f92466fba16ea70.jpeg,/Tutorial/images/products/cbdb9c00777577c34f3ed35962b62835.jpeg,/Tutorial/images/products/6f1e858d49393d3396957cd5b8ce2a1b.jpeg,/Tutorial/images/products/7ea49e17a742ecf0b1baf8166fc020f2.jpeg', 'Featuring a slim profile, sleek design and innovative technologies, the MacBook Pro is built to perform. The Touch Bar above its keyboard is a multi-touch enabled strip of glass that puts a host of tools right at your fingertips for instant access. The 38.1 cm Retina Display guarantees stunning visuals with realistically vivid details. It comes with powerful inbuilt speakers that deliver up to 58 percent more volume than standard laptops. With a Force Touch trackpad, this laptop offers your fingers more room to gesture and click. Further adding to its powerful performance are the Intel Core i7 processor, 256 GB SSD, 16 GB DDR3 RAM and Radeon Pro 450 GPU.\r\n\r\n\r\nLaptop, Power Adaptor, User Guide, Warranty Documents\r\nModel Number\r\nMLW72HN/A\r\nModel Name\r\nMacbook Pro\r\nSeries\r\nMacbook Pro\r\nColor\r\nSilver\r\nType\r\nLaptop\r\nSuitable For\r\nEveryday Use, Processing &amp; Multitasking, Travel &amp; Business\r\nBattery Backup\r\nUpto 10 hours\r\n', 1, '15 inch:5:2', 0),
(35, 'Puma Boys &amp; Girls Lace Sneakers (Blue)', '49.99', '69.99', 26, '27', '/Tutorial/images/products/762fbb367477a2debc15e409a953183c.jpeg,/Tutorial/images/products/f0a222d8b26a73c023deeecc9bff6454.jpeg,/Tutorial/images/products/a886089ddbd07bdff567038866efd9e5.jpeg', 'An apex is a highest point; in other words, a &ldquo;top&rdquo;. These shoes, arguably, qualify. We&rsquo;re pretty sure they&rsquo;re going to be your tops. Technically striking and totally comfortable, we&rsquo;ve definitely reached a high design point here.FEATURES + BENEFITS Ethylene-vinyl acetate: durable, moulded, cushioned comfort Sneakers Textile upper with asymmetrical lace closure Non-marking rubber outsole Featuring split vamp and flow mould details PUMA Formstrip Unisex.\r\n\r\nNumber of Pairs\r\n1\r\nGeneral\r\nBrand\r\nPuma\r\nStyle Code\r\n36620402\r\nSize\r\n4\r\nBrand Color\r\nPeacoat- White- Black\r\nIdeal For\r\nBoys &amp; Girls\r\nType\r\nCasual Wear\r\nSub Type\r\nSneakers\r\nPrimary Color\r\nBlue\r\nClosure Type\r\nLace\r\nOuter Material\r\nFabric\r\nSole Material\r\nRubber\r\nHeel Design\r\nNA\r\nHeel Height\r\nNA\r\nSecondary Color\r\nBlue\r\nCharacter\r\nNone', 1, '6:4:5,8:4:2', 0),
(36, 'Adbucks Three Fourth For Boys  (Beige Pack of 2)', '49.99', '69.99', 27, '14', '/Tutorial/images/products/cbce50c85dc066a3fc9f6fbf23e347c7.jpeg,/Tutorial/images/products/22dfb87c12135ff17b5c4885db11783a.jpeg,/Tutorial/images/products/7ced600e765ff0952f0a4dc4f1fecc33.jpeg,/Tutorial/images/products/c96568ebcf2af9c92cdd89a9e0f46e0b.jpeg', 'AdBucks presents to you wide range of boys (Kids) cargos pants. About Us: Established in 1992, we are a prominent manufacturer and trader of Boys,Girls, Gents Jeans, Ladies Jeans / Jeggings / Leggings / Shorts, Readymade Dress, Shirts, T-Shirts, Ladies Tops under the Brand Name of &ldquo;AdBucks&rdquo;. Our organization works on the principles of unmatched quality, speedy delivery and maximum customer satisfaction. Our quality centric approach has enabled us to meet the demands of our reputed clients successfully and win their undeterred trust; thus becoming a renowned name in the industry ourselves.\r\n\r\nNumber of Three Fourths\r\n2\r\nGeneral\r\nBrand\r\nAdbucks\r\nStyle Code\r\nKids_Shorts_Gold:Beige\r\nBrand Color\r\nBeige\r\nSize\r\n3 - 4 Years\r\nIdeal For\r\nBoys\r\nFabric\r\nCotton\r\nOccasion\r\nCasual\r\nPrimary Color\r\nBeige\r\nPattern\r\nSolid\r\nFabric Details\r\n100% Cotton', 1, '4-5 yrs:4:3,6-8 yrs:4:2', 0),
(37, 'Fingerchips Boy&#039;s Graphic Print Casual Shirt', '39.99', '59.99', 28, '13', '/Tutorial/images/products/505b720fc2c4f39ed91c7f35598baac2.jpeg,/Tutorial/images/products/272c8bb9c47edf0f745d091b5bc09822.jpeg,/Tutorial/images/products/c3bba8ad7d9a571cd06dc280b4280b70.jpeg', 'Pack of\r\n1\r\nStyle Code\r\nFCS_2540_Red\r\nFit\r\nSlim\r\nFabric\r\nDenim\r\nSleeve\r\nFull Sleeve\r\nPattern\r\nGraphic Print\r\nReversible\r\nNo\r\nFabric Care\r\nGentle Machine Wash in Lukewarm Water, Do Not Bleach\r\nSuitable For\r\nWestern Wear\r\nMore Details\r\nGeneric Name\r\nShirt', 1, '5-8 yrs:4:2,8-12yrs:4:2', 0),
(38, 'Fingerchips Boys Graphic Print Party Shirt  (Pack of 2)', '59.99', '79.99', 28, '13', '/Tutorial/images/products/281228778fadf771bcd3379e80dd9841.jpeg,/Tutorial/images/products/6b3d0bc56fee23f7a4d8b2b04e3bc1cf.jpeg,/Tutorial/images/products/7dbaf6adeca2f914b006ecbc5aef7344.jpeg,/Tutorial/images/products/334f4a428a2b8137603682f62c0b0b87.jpeg,/Tutorial/images/products/ea54ce9068ceb3bec4252820158c9d11.jpeg', 'Fingerchips designer party wear shirt with graphic print T-shirt\r\nSpecifications\r\nPack of\r\n2\r\nStyle Code\r\nFCS_2272_KHAKI\r\nFit\r\nSlim\r\nFabric\r\nCotton\r\nSleeve\r\nFull Sleeve\r\nPattern\r\nGraphic Print\r\nReversible\r\nNo\r\nFabric Care\r\nGentle Machine Wash in Lukewarm Water, Do Not Bleach\r\nSuitable For\r\nWestern Wear\r\nMore Details\r\nGeneric Name\r\nShirt', 1, '6-8 yrs:4:2,8-10 yrs:4:2', 0),
(39, 'Kidopedia Boys Solid Casual Button Down Shirt', '49.99', '69.99', 29, '13', '/Tutorial/images/products/6cfa2e0c8aae6dc93c2f996a3abb8adb.jpeg,/Tutorial/images/products/864800508c2bb1b303fd2e30d28ec7e3.jpeg,/Tutorial/images/products/566933adca7d34b6f7e99ab84f34448e.jpeg', 'Pack of\r\n1\r\nModel Name\r\nBoys Diagonal Panel Shirt\r\nStyle Code\r\nKP1052\r\nClosure\r\nButton\r\nFit\r\nRegular\r\nFabric\r\nCotton\r\nSleeve\r\nFull Sleeve\r\nPattern\r\nSolid\r\nReversible\r\nNo\r\nCollar\r\nButton Down\r\nFabric Care\r\nGentle Machine Wash\r\nSuitable For\r\nWestern Wear\r\nMore Details\r\nGeneric Name\r\nShirt', 1, '10-12 yrs:4:2,12-15 yrs:6:2', 0),
(40, 'Flying Machine Slim Men&#039;s Black Jeans', '59.99', '79.99', 30, '6', '/Tutorial/images/products/bdb4ba9c404e00a6741f8a3aa68c9b3b.jpeg,/Tutorial/images/products/b1e00ff5862ecb244d6fa4ced908e2ce.jpeg,/Tutorial/images/products/b61c474b2ce1955ac4a5f852c0f3c083.jpeg', 'Highlights\r\nFit: MJ Mankle\r\nFabric: Cotton\r\nMid Rise Jeans\r\nClean Look\r\nServices\r\n\r\n\r\nStyle Code\r\nFMJNO0142Black\r\nIdeal For\r\nMen&#039;s\r\nSuitable For\r\nWestern Wear\r\nPack Of\r\n1\r\nReversible\r\nNo\r\nClosure\r\nButton\r\nFabric\r\nCotton\r\nFaded\r\nClean Look\r\nRise\r\nMid Rise\r\nDistressed\r\nClean Look\r\nFit\r\nMJ Mankle\r\nFly\r\nZipper\r\nModel Details\r\nThis model has a height of 6 feet 0 inches and is wearing a of Size', 1, '28:4:2,30:4:2,32:5:2', 0),
(41, 'Metronaut Slim Men&#039;s Light Blue Jeans', '49.99', '59.99', 31, '6', '/Tutorial/images/products/33a84c61cfab8604f1548e5f0f88ea3a.jpeg,/Tutorial/images/products/ab84d0ad940ff63bc7d47182181ba57c.jpeg,/Tutorial/images/products/eb195fd548f844a2fe872bea5959ac89.jpeg,/Tutorial/images/products/57a02fc723e88d517facf968b8897243.jpeg,/Tutorial/images/products/ba35244c0659dcfbb6bfe34fea572266.jpeg', 'Highlights\r\nFit: Slim\r\nFabric: Cotton Polyester Blend\r\nLight Fade Mid Rise Jeans\r\nClean Look\r\n\r\n\r\nStyle Code\r\nMW17JNHF003\r\nIdeal For\r\nMen&#039;s\r\nSuitable For\r\nWestern Wear\r\nPack Of\r\n1\r\nPattern\r\nSolid\r\nReversible\r\nNo\r\nClosure\r\nButtoned\r\nFabric\r\nCotton Polyester Blend\r\nFaded\r\nLight Fade\r\nRise\r\nMid Rise\r\nDistressed\r\nClean Look\r\nFit\r\nSlim\r\nFly\r\nZipper\r\nFabric Care\r\nDo not Bleach, Do not Wring, Dry in Shade\r\nModel Details\r\nThis model has a height of 6 feet 0 inches and is wearing a of Size', 1, '28:3:2,30:5:2,32:4:2', 0),
(42, 'Beevee Men&#039;s Cargos', '39.99', '59.99', 32, '6', '/Tutorial/images/products/6cb5d7eff738e389d9e19691d42f4d98.jpeg,/Tutorial/images/products/a046d6a5c2e565d165618ec18c95fff6.jpeg,/Tutorial/images/products/e9913fa1e8e69c37e9da33070debe6b4.jpeg,/Tutorial/images/products/25e9cc26e42b9e1889432ea973acff33.jpeg,/Tutorial/images/products/ad06ab6b12d5d605647e9c19c0a021f2.jpeg,/Tutorial/images/products/7877298db6d091db84a5ff75767ffa22.jpeg', 'Highlights\r\nMen&#039;s Cargo Pants\r\nMade of 100% Cotton\r\nColor: Black\r\nSolid Pattern\r\nPack of 1\r\n\r\n\r\nFit\r\nRegular Fit\r\nFly\r\nZipper\r\nFabric Care\r\n100% Cotton\r\nOther Details\r\n1 Cargo Pant\r\nOther Dimensions\r\nDrawstring\r\nSales Package\r\nBeevee 100% Cotton Solid Black Fixed Waist Cargo Pant With Drawstring', 1, '28:3:2,30:5:2,32:6:2', 0),
(43, 'Smoky Trendy Party Lace Up For Men', '49.99', '59.99', 33, '7', '/Tutorial/images/products/dec98860bb15a030775385e8d5e7424b.jpeg,/Tutorial/images/products/5125967ff4b5ede95b68099b48d6464e.jpeg,/Tutorial/images/products/8ec054e5d6f07734dd0d51062b280c4d.jpeg,/Tutorial/images/products/fce5a4caf37d2977a1b01ceb89076c81.jpeg,/Tutorial/images/products/edcd5e53c16a9183f536ed7bc512c39d.jpeg', 'Highlights\r\nColour: Brown\r\nOuter Material: Synthetic Leather\r\nInner Material: Comfort Foam\r\nClosure: Laced\r\nPattern: Solid\r\n\r\nModel Name\r\nTrendy Party\r\nIdeal For\r\nMen\r\nOccasion\r\nFormal\r\nInner Material\r\nComfort Foam\r\nOuter Material\r\nSynthetic Leather', 1, '7:4:2,8:5:2,9:5:2', 0),
(44, 'Kraasa 1018 Slip On Shoe For Men', '59.99', '69.99', 34, '7', '/Tutorial/images/products/8cb11df24232b3078bad192983bbef78.jpeg,/Tutorial/images/products/dd7b38e949ae4a3c7c43f64b100c8272.jpeg,/Tutorial/images/products/b5a022b8acc772c429c3a90959326a9f.jpeg,/Tutorial/images/products/e2c45a53d73de89f936183a4655c30b7.jpeg,/Tutorial/images/products/ed34c966426887f1e2cd2f1580b302a4.jpeg', 'Colour: Black\r\nOuter Material: Artificial Leather\r\n\r\nThis pair of black artificial leather shoes is the last thing you need to slip on for that finishing touch to your elegant tux or suit before you head out for your Saturday evening. The formal look of the shoes will go well with your black attire or complement the look of any colored shirt that you wear.\r\nModel Name\r\n1018\r\nIdeal For\r\nMen\r\nOccasion\r\nFormal\r\nOuter Material\r\nArtificial Leather\r\n', 1, '7:5:2,8:5:2,9:6:2', 0),
(45, 'Kraasa The Rock Boots For Men  (Beige)', '59.99', '69.99', 34, '7', '/Tutorial/images/products/6a6b37bf8d87fe8a8f9de37c3f35133e.jpeg,/Tutorial/images/products/78ad9500e76972ecbe8eeef628b3cd6d.jpeg,/Tutorial/images/products/b2411ccf31db9c3b35ee1953bfc17a62.jpeg,/Tutorial/images/products/5287bd1d4973b6a2a2e10109adbaf101.jpeg', 'Colour: Beige\r\n0.5 inch Heel Height\r\nOuter Material: Synthetic Leather\r\nClosure: Laced\r\nPattern: Solid\r\n\r\nGeneral\r\nModel Name\r\nThe Rock\r\nIdeal For\r\nMen\r\nOccasion\r\nCasual\r\nOuter Material\r\nSynthetic Leather\r\nProduct Details\r\nUpper Pattern\r\nSolid\r\nTip Shape\r\nRound\r\nClosure\r\nLaced', 1, '7:5:2,8:5:2,9:5:2', 0),
(46, 'Polo Ralph Lauren Premium Leather Wallet  (6 Card Slots)', '99.99', '129.99', 7, '8', '/Tutorial/images/products/1ec78b8021444e111e090998e0485a61.jpeg,/Tutorial/images/products/40b4067df6d367eab1b6aeb8dbaff9e6.jpeg,/Tutorial/images/products/12aa0115722ed098a21a553fa6de529b.jpeg,/Tutorial/images/products/a52607649daac7188aa7a448c79d0927.jpeg,/Tutorial/images/products/495d272f1693fd3f83bc335fa76ef8d7.jpeg', 'Wallet for Men\r\nMaterial: Genuine Leather\r\nDimensions: 3 inch x 4 inch\r\nCard Slots: 6', 1, '3x4 inch:5:2', 0),
(47, 'Emporio Armani Men Black Genuine Leather Wallet(8 Card Slots)', '99.99', '120.99', 35, '8', '/Tutorial/images/products/b7469bea54c3ad6b6f6cc74c19f4e140.jpeg,/Tutorial/images/products/acc1bb879487d7b396e1da756335da47.jpeg,/Tutorial/images/products/f13c7fc73196d6a5c3019ad9a7f5aed9.jpeg,/Tutorial/images/products/eb64266efe4331de7cadada88f87819d.jpeg,/Tutorial/images/products/6a7d4e151a2203c3edac644843e31dea.jpeg,/Tutorial/images/products/dc7d6b602bd1c9c86eddc7b9ec9f6365.jpeg', 'Wallet for Men\r\nMaterial: Genuine Leather\r\nDimensions: 3.8 inch x 4.2 inch\r\nCard Slots: 8\r\n', 1, '3x4 inch:5:2', 0),
(48, 'GUCCI Men Beige, Black Genuine Leather, Canvas Belt#Imported', '99.99', '120.99', 36, '8', '/Tutorial/images/products/dd9941152be77be674b04ba3020dfa2e.jpeg', 'Material: Genuine Leather, Canvas\r\nImportant Note\r\nDelivery of this product will take more time as it is imported on demand from USA. Please refer to delivery date for details.', 0, '36 inch:5:2', 0),
(49, 'Saints Secrets Party Short Sleeve Solid Women&#039;s Black Top', '49.99', '69.99', 37, '9', '/Tutorial/images/products/fb529f3e43275859b8387d8a5b171798.jpeg,/Tutorial/images/products/7b7cbe541cdd81a78589cec82a4384c9.jpeg,/Tutorial/images/products/29a37f0905e927c63e90cce3eea39f76.jpeg,/Tutorial/images/products/4591ebb708d01390ad1b85bb6c80d832.jpeg', 'Specifications\r\nFabric Care\r\nMachine Wash as per Tag\r\nMore Details\r\nGeneric Name\r\nTops\r\n\r\nRound Neck, Short Sleeve\r\nFabric: Viscose Blend\r\nPattern: Solid\r\nType: Top\r\nPack of 1', 1, 'XL:5:3,X:5:2,M:5:2', 0),
(50, 'CRAFTBAZAR Embroidered 100% Women Kaftan', '59.99', '69.99', 38, '9', '/Tutorial/images/products/0a56138e9279708cf175b3c0806d6696.jpeg,/Tutorial/images/products/15c9c71f93ae52be5be8b883b893ae39.jpeg,/Tutorial/images/products/b413f1b28e55007d75d77fdf3fdab399.jpeg,/Tutorial/images/products/d22d48b8522e58b4f01dc507fd6a687f.jpeg,/Tutorial/images/products/f73449078b68c7fec889b8af7d208c30.jpeg', 'Suitable For\r\nWestern Wear, Ethnic Wear, Maternity Wear\r\nStyle Code\r\nCRB020\r\nNumber of Kastans\r\nPack of 1\r\nOccasion\r\nCasual, Party, Beach Wear\r\nSecondary Color\r\nWhite\r\nFabric Care\r\nDry clean only', 1, 'X:5:2,XL:5:2,M:2:2', 0),
(51, 'Living Doll Regular Women&#039;s Blue Jeans', '49.99', '59.99', 39, '10', '/Tutorial/images/products/ae9eb319b3053bd0336bb4753d34c9e5.jpeg,/Tutorial/images/products/58d0c7048263435cca68e496c11b6c40.jpeg,/Tutorial/images/products/8bd615046ecd3c7d049a4508c11429c7.jpeg,/Tutorial/images/products/a73d2b51c8c8c58e2c2a994ebc3c7f72.jpeg,/Tutorial/images/products/e92e9c4ac2ea1d36f1087ff86b71b3a9.jpeg', 'Style Code\r\nBENJI-BLUE\r\nIdeal For\r\nWomen&#039;s\r\nSuitable For\r\nWestern Wear\r\nPack Of\r\n1\r\nReversible\r\nNo\r\nFabric\r\nCotton\r\nFaded\r\nHeavy Fade\r\nRise\r\nMid Rise\r\nDistressed\r\nHigh Distress\r\nFit\r\nRegular', 1, '26:5:2,28:5:2,30:5:2', 0),
(52, 'Levi&#039;s Skinny Women&#039;s Blue Jeans', '59.99', '69.99', 1, '10', '/Tutorial/images/products/27e7cf49f6f1c1106660788d6e1d792e.jpeg,/Tutorial/images/products/7c55e043a01d260321bbddffaef248f5.jpeg,/Tutorial/images/products/8745d6fd3e2901ff864daddbe8a848b3.jpeg,/Tutorial/images/products/f69caf53840b1b44fc6f45c273bc761d.jpeg,/Tutorial/images/products/16f0e9d7d4f133e2777e4ed1ccbaad25.jpeg,/Tutorial/images/products/385e876bff00e5242faeb468ff0bb938.jpeg', 'Style Code\r\n21306-0210Blue\r\nIdeal For\r\nWomen&#039;s\r\nSuitable For\r\nWestern Wear\r\nPack Of\r\n1\r\nPattern\r\nSolid\r\nReversible\r\nNo\r\nClosure\r\nButtoned\r\nFabric\r\nCotton\r\nFaded\r\nLight Fade\r\nRise\r\nMid Rise\r\nDistressed\r\nClean Look\r\nFit\r\nSkinny\r\nFly\r\nZipper\r\nFabric Care\r\nDo not Bleach\r\nModel Details\r\nThis model has a height of 5 feet 9 inches and is wearing a of Size', 0, '26:5:2,28:5:2,30:5:2', 0),
(53, 'Carlton London CLL-3844 Boots For Women  (Navy)', '59.99', '69.99', 40, '11', '/Tutorial/images/products/1f5edf56225f9e303c366575c2da31ba.jpeg,/Tutorial/images/products/efabadc96c85b755c6eef4f4435406fc.jpeg,/Tutorial/images/products/96415b7851736c9be7ad4101b57e1d3d.jpeg,/Tutorial/images/products/2f7277c9ce540552c53e3b75303535d6.jpeg', 'Specifications\r\nGeneral\r\nModel Name\r\nCLL-3844\r\nIdeal For\r\nWomen\r\nOccasion\r\nCasual\r\nOuter Material\r\nSynthetic Leather\r\nProduct Details\r\nTip Shape\r\nPointed\r\nSeason\r\nAW16', 0, '7:5:2,8:5:2,9:5:2', 0),
(54, 'Accessorize Women Black PU Sling Bag', '99.99', '129.99', 41, '17', '/Tutorial/images/products/dd4c48c489f21b08879d9dde24088eac.jpeg,/Tutorial/images/products/946ddf16ed2cc40ee1ace49c6955a449.jpeg,/Tutorial/images/products/28405b61c61a2f01d30b48def04cfd9f.jpeg,/Tutorial/images/products/c778fb726d8cefdd6dfa388e18c2823f.jpeg,/Tutorial/images/products/fb64a618843aeb763b79978e5899dd0a.jpeg', 'General\r\nModel Name\r\nMN-49042103001\r\nBag Size\r\nSmall\r\nNumber of Compartments\r\n1\r\nPattern\r\nTextured\r\nPack of\r\n1\r\nDimensions\r\nWidth\r\n17 cm\r\nHeight\r\n13 cm\r\nDepth\r\n13 cm\r\nWeight\r\n300 g\r\nMore Details\r\nGeneric Name\r\nSling Bags\r\nCountry of Origin\r\nChina, South Korea, India, Thailand, Taiwan (Originated from one of these countries)', 0, 'small:5:2,medium:5:2,large:5:2', 0),
(55, 'Crocs Crocs Leigh Suede Mix Bootie W Boots For Women  (Grey)', '99.99', '129.99', 42, '16', '/Tutorial/images/products/3cac2ae51d65f19e70a89ee83991ac44.jpeg,/Tutorial/images/products/c88c4128d44fc2ba988a1e9a4ccb67a6.jpeg,/Tutorial/images/products/76866204e240c8a2d9e9de6e94b5ba1c.jpeg,/Tutorial/images/products/7a0dd60dc92a7a28ef427d79002cf84b.jpeg', 'General\r\nModel Name\r\nCrocs Leigh Suede Mix Bootie W\r\nIdeal For\r\nWomen\r\nOccasion\r\nCasual\r\nOuter Material\r\nSuede\r\nHeel Pattern\r\nNA\r\nProduct Details\r\nUpper Pattern\r\nNA\r\nCare Instructions\r\nUse a damp cloth to remove dust and dirt. Avoid suing solvent cleaners wherever possible.', 1, '7:4:2,8:4:2', 0),
(56, 'Satva Solid Women Black Track Pants', '49.99', '69.99', 43, '28', '/Tutorial/images/products/b4e7f8a17addfdf655550a9885d181a6.jpeg,/Tutorial/images/products/03f2c3fedc2953db2ad775732f027249.jpeg,/Tutorial/images/products/881c8be4d44bde3c5c7fb510e164d56d.jpeg,/Tutorial/images/products/e54f4d8e4a3d2fc2a443b4e1a045ccc6.jpeg', 'Style Code\r\nWS1870CBK\r\nClosure\r\nElastcicated Waistband with Drawstring\r\nPockets\r\n2 Side Pockets\r\nFabric Care\r\nWash with like colors only. Machine wash (Gentle stroke) at 30&deg; C. Do Not Bleach. Do Not Tumble Dry.\r\nOther Details\r\nGreat for: Sports, Yoga, Jogging, Workout, Everyday.', 1, '26:5:2,28:5:2', 0);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `charge_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cart_id` int(11) NOT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(175) COLLATE utf8_unicode_ci NOT NULL,
  `street` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `street2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(175) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(175) COLLATE utf8_unicode_ci NOT NULL,
  `zip_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(176) COLLATE utf8_unicode_ci NOT NULL,
  `sub_total` decimal(10,2) NOT NULL,
  `tax` decimal(10,2) NOT NULL,
  `grand_total` decimal(10,2) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `txn_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `txn_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=38 ;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `charge_id`, `cart_id`, `full_name`, `email`, `street`, `street2`, `city`, `state`, `zip_code`, `country`, `sub_total`, `tax`, `grand_total`, `description`, `txn_type`, `txn_date`) VALUES
(4, '', 26, 'Deepranjan', 'deep@gmail.com', '22', 'Sector 9/C', 'Bokaro Steel City', 'Jharkhand', '827009', 'India', '211.94', '18.44', '230.38', '6 items from E-fashion Store', '', '2018-01-23 18:27:48'),
(5, 'ch_1CD3PAHjhDMD5l4SMdkJX6rB', 29, '', 'kd0824422@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-04 10:09:30'),
(15, 'ch_1CDcN9HjhDMD5l4SUportKbh', 38, '', 'kd0824422@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-05 23:29:46'),
(22, 'ch_1CE7rLHjhDMD5l4SolgVihba', 47, '', 'kd0824422@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-07 09:07:01'),
(26, 'ch_1CE81NHjhDMD5l4SKict3HzU', 50, '', 'kd0824422@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-07 09:17:23'),
(27, 'ch_1CE83AHjhDMD5l4SLy5b0aXR', 50, '', 'kd0824422@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-07 09:19:15'),
(28, 'ch_1CE87THjhDMD5l4SUZJvjb6u', 50, '', 'kd0824422@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-07 09:23:41'),
(29, 'ch_1CE891HjhDMD5l4SG9RdyCf6', 50, '', 'kd0824422@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-07 09:25:17'),
(30, 'ch_1CE8DbHjhDMD5l4SFgsGxp2N', 50, '', 'kd0824422@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-07 09:30:02'),
(31, 'ch_1CE8FVHjhDMD5l4S1eHPdN5L', 0, '', 'kd0824422@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-07 09:31:59'),
(32, 'ch_1CE8KYHjhDMD5l4SdRlFoD3e', 51, '', 'kd0824422@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-07 09:37:13'),
(33, 'ch_1CE8MfHjhDMD5l4Sk1DRtpB9', 51, '', 'kd0824422@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-07 09:39:23'),
(34, 'ch_1CKe7pHjhDMD5l4SNdvgX7j2', 0, '', 'kd082442@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-25 08:46:59'),
(35, 'ch_1CMd1xHjhDMD5l4SHNCGCyCG', 0, '', 'kd082442@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-30 20:01:07'),
(36, 'ch_1CMd4GHjhDMD5l4S8szkYfma', 0, '', 'kd082442@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-30 20:03:30'),
(37, 'ch_1CMd5SHjhDMD5l4SuzUBarky', 0, '', 'kd082442@gmail.com', '', '', '', '', '', '', '0.00', '0.00', '0.00', '', 'charge', '2018-04-30 20:04:44');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(175) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `join_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` datetime NOT NULL,
  `permissions` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `join_date`, `last_login`, `permissions`) VALUES
(1, 'Kumar Deepu', 'deepu@gmail.com', '$2y$10$7YaxrHbArOOo2VBxJ3RivOKkFgrEzl0madyn.GhpbPW8gjnizDxim', '2018-01-05 08:57:57', '2018-05-02 04:11:08', 'admin,editor'),
(5, 'Test Testerson', 'test@gmail.com', '$2y$10$3SpfbPZ52RYj0c8xEwv0Lu8BtYT8XsnxsEPhiPYtqcXEDoIuRlITe', '2018-01-07 10:27:43', '2018-02-03 05:13:52', 'editor'),
(6, 'Test Account', 'testaccount@gmail.com', '$2y$10$F91sW45JjUwO/P4fXOUfy.O41mkvFDyKRml5w3A4zKSmcESbSwHQO', '2018-05-02 08:01:55', '2018-05-02 04:32:17', 'admin,editor');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
