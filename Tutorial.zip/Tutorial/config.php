<?php
define('BASEURL', $_SERVER['DOCUMENT_ROOT'].'/tutorial/');
define('CART_COOKIE','SBwiz223ertyGHwiz321');
define('CART_COOKIE_EXPIRE',time() + (86400 *30));
define('TAXRATE', 0.087);//Sales Tax rate. Set to 0 if you aren't charging yet.

define('CURRENCY', 'usd');
define('CHECKOUTMODE','TEST'); //change test to live when you are ready to go live

if (CHECKOUTMODE == 'TEST') {
	define('STRIPE_PRIVATE','sk_test_UjHsY7lPoICRvQp6Cz0SvCgO');
	define('STRIPE_PUBLIC','pk_test_lFXON2cHBNM0aN5gKFn2n5B1');
}

if (CHECKOUTMODE == 'LIVE') {
	define('STRIPE_PRIVATE','');
	define('STRIPE_PUBLIC','');
}
?>
<?php
require_once('vendor/autoload.php');

$stripe = array(
  "secret_key"      => "sk_test_UjHsY7lPoICRvQp6Cz0SvCgO",
  "publishable_key" => "pk_test_lFXON2cHBNM0aN5gKFn2n5B1"
);

\Stripe\Stripe::setApiKey($stripe['secret_key']);
?>