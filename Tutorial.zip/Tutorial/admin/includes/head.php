<!DOCTYPE html>
<html>
<head>
	<title>Administrator</title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="/Tutorial/css/main3.css">
	<meta charset="utf-8">
	<script type="text/javascript" src="/Tutorial/js/jquery2.js"></script>
	<script type="text/javascript" src="/Tutorial/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://js.stripe.com/v3/"></script>
</head>
<body>
<div class="container-fluid">