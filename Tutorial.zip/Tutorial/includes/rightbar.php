<!--Right Side Bar-->
	<div class="col-md-2">
		<?php 
			include 'widgets/cart.php';
			include 'widgets/recent.php';
		?>
	</div>