<!-- Header -->
	<div id="partial-headerWrapper">
		<div id="partial-back-flower"></div>
		<div id="partial-logotext"></div>
		<div id="partial-fore-flower"></div>
	</div>
	<!-- Full Page Wrapper-->
<div class="container-fluid">